# EposNowImportSplitter
Takes a CVS files and splits it into multiple files with a max of 4000 lines each for importing to EPOS (Sorry if you're using EPOS, they put the POS in POS)

Just update the paths at the beginning of the Main function and you should be good to go!
